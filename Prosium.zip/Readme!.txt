Prosium is a GDI Malware
Created by: Pminh141 (Phumg Minh)
Made in: C++, ASM
Works Best In: Windows XP
Created In: Dev C++
Malware name: Prosium
This Trojan Is Not A Joke, Do You want to run it?